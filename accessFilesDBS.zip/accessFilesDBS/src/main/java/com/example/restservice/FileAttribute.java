package com.example.restservice;
import java.nio.file.attribute.FileTime;

public class FileAttribute {
	private final String creationTime;
	private final String lastAccessTime;
	private final String lastModifiedTime;
	private final boolean isDirectory;
	private final boolean isOther;
	private final boolean isRegularFile;
	private final boolean isSymbolicLink;
	private final long size;

	public FileAttribute(){
		this.creationTime = "";
		this.lastAccessTime = "";
		this.lastModifiedTime = "";
		this.isDirectory = false;
		this.isOther = false;
		this.isRegularFile = false;
		this.isSymbolicLink = false;
		this.size = 0L;
		}

	public FileAttribute(String creationTime, String lastAccessTime,
		String lastModifiedTime, boolean isDirectory, boolean isOther,
		boolean isRegularFile, boolean isSymbolicLink, long size) {
		this.creationTime = creationTime;
		this.lastAccessTime = lastAccessTime;
		this.lastModifiedTime = lastModifiedTime;
		this.isDirectory = isDirectory;
		this.isOther = isOther;
		this.isRegularFile = isRegularFile;
		this.isSymbolicLink = isSymbolicLink;
		this.size = size;
	}
		public String getCreationTime() {
			return creationTime;
		}

		public String getLastAccessTime() {
			return lastAccessTime;
		}

		public String getLastModifiedTime() {
			return lastModifiedTime;
		}

		public boolean isDirectory() {
			return isDirectory;
		}

		public boolean isOther() {
			return isOther;
		}

		public boolean isRegularFile() {
			return isRegularFile;
		}

		public boolean isSymbolicLink() {
			return isSymbolicLink;
		}

		public long getSize() {
			return size;
		}

}