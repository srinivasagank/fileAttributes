package com.example.restservice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;

@RestController
public class FileAttributeController {

	@GetMapping("/fileInfo")
	public FileAttribute fileInfo(@RequestParam(value = "filename", defaultValue = "curfew-english.docx") String filename) {
		String HOME = System.getProperty("user.home");
		BasicFileAttributes attr;
		try {
			Path file = Paths.get(HOME+"/Desktop",filename);
			attr = Files.readAttributes(file, BasicFileAttributes.class);
		}
		catch (java.io.IOException ex)
		{
			return new FileAttribute();
		}
		FileAttribute fileAttribute = new FileAttribute(attr.creationTime().toString(), attr.lastAccessTime().toString(),
		attr.lastModifiedTime().toString(), attr.isDirectory(),
		attr.isOther(), attr.isRegularFile(), attr.isSymbolicLink(), attr.size());
		return fileAttribute;
	}

/*
	@GetMapping("/dirInfo")
	public ArrayList<FileAttribute> dirInfo(@RequestParam(value = "dirname", defaultValue = ".") String dirname){
		BasicFileAttributes attr;
		ArrayList<FileAttribute> fileAttr = new ArrayList<FileAttribute>();
		Stream<Path> files = null;
		try {

			files = Files.list(Paths.get(dirname));
				files.forEach(p -> fileAttr.add(populateAttribute(p)));
		}
		catch (Exception ex){
			return fileAttr;
		}
		return fileAttr;
	}
*/
	private FileAttribute populateAttribute(Path path) throws IOException{
		FileAttribute fileAttribute = new FileAttribute();
		BasicFileAttributes attr;
		try {
			attr = Files.readAttributes(path, BasicFileAttributes.class);
		}
		catch (IOException ex){
			return fileAttribute;
		}
			fileAttribute = new FileAttribute(attr.creationTime().toString(), attr.lastAccessTime().toString(),
			attr.lastModifiedTime().toString(), attr.isDirectory(),
			attr.isOther(), attr.isRegularFile(), attr.isSymbolicLink(), attr.size());
			return fileAttribute;

	}



}